<template>
  <div class="wip">
    <h1>Work in Progress</h1>
  </div>
</template>
