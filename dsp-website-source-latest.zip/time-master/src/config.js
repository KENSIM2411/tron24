export const contractAddress = process.env.VUE_APP_CONTRACT_ADDRESS;
export const zeroAddress = localStorage.getItem('referrerAddress') || "TFqiUZ1VTi2wqB1MJqkDzavH8aN3q7REL1";