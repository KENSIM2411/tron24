<template>
    <v-dialog max width="300px">
        <v-btn  x-small dark color="#5E35B1" @click.stop="dialog = true">This is a test</v-btn>
        <v-card>
            <v-card-title>Enter Auction</v-card-title>
        </v-card>
    </v-dialog>
</template>


<script>
export default {
    
}
</script>