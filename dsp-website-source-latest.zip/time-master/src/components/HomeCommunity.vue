<template>
        <section id="d2x-community" class="section">
        <div class="container">
            <img src="../assets/images/DefiStakingPlatform_logo_transparent-v3.png" alt="DeFi Staking Platform Logo" />
            <h1>Join our <span>Community</span></h1>
            <p>Learn more about the project, interact with the team, and take a part in shaping the future of DeFi Staking Platform.</p>

            <div class="row">
                <div class="col-md-6" data-aos="fade-up" data-aos-delay="100">
                    <a href="https://t.me/dsptokenchat" target="_blank"><i class="fab fa-telegram-plane"></i> Telegram</a>
                </div>
                <!-- <div class="col-md-6" data-aos="fade-up" data-aos-delay="150" data-aos-offset="120">
                    <a href="" target="_blank"><i class="fab fa-discord"></i> Discord</a>
                </div> -->
                <div class="col-md-6" data-aos="fade-up" data-aos-delay="175" data-aos-offset="150">
                    <a href="https://twitter.com/StakingDefi" target="_blank"><i class="fab fa-twitter"></i> Twitter</a>
                </div>
                <!-- <div class="col-md-6" data-aos="fade-up" data-aos-delay="200" data-aos-offset="200">
                    <a href="#" target="_blank"><i class="fab fa-reddit-alien"></i> Reddit</a>
                </div> -->
            </div>

            <hr>
        </div>
    </section>
</template>
<script>
export default {
    
}
</script>

