<template>
 <section id="d2x-benefits" class="section white-bg">
        <div class="container">
            <div class="row" style="overflow-x: hidden">
    
    
                <div class="col-md-4 col-sm-6" data-aos="fade-left">
                    <div class="d2x-benefits-box">
                        <i class="far fa-calendar-check"></i>
                        <h4>Daily Auction Lobby</h4>
                        <p>Our Daily Auctions will start from 2.5 million DSP tokens per day and will be distributed between the users that participated in Auction based on their purchase amount. This will reduce over the next 365 days.</p>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6" data-aos="fade-left">
                    <div class="d2x-benefits-box">
                        <i class="fas fa-redo-alt"></i>
                        <h4>Daily TRON Dividends</h4>
                        <p>Everyday 95% of the previous day's TRX that was spent in the Auction Lobby will be pooled and allocated to users based upon their completed stake terms.</p>
                    </div>
                </div>

                <div class="col-md-4 col-sm-6" data-aos="fade-left">
                    <div class="d2x-benefits-box">
                        <i class="fas fa-tint"></i>
                        <h4>Lucrative Staking System</h4>
                        <p>Stake your DSP tokens within the Staking Portal and earn daily interest. Additionally, Stakers are rewarded TRX tokens from the daily Lobbies based off the percentage of total tokens being Staked.</p>
                    </div>
                </div>

            </div>
        </div>
    </section>

</template>

<style>

</style>